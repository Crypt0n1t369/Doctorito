# Training-centre parsing instrument — handoff 2.1

Bundle 2.1 turns the accepted 2.0 restructure into an executable foundation. It is an
internal parsing and governed-data instrument, not a user-facing product.

For day-to-day instructions, oversight and manual corrections, start with
`OPERATOR-GUIDE.md` and run `./tcpipe --help`.

## Authority order

1. `FOUNDATION-2.1.md` and executable tests describe the current foundation.
2. `ADDENDUM-2.0-restructure.md` explains the restructuring decision.
3. Amendments A1–A3 still govern recovery evidence and SQLite foreign keys.
4. V3 Parts 4, 7, 12 and 13 remain historical where they conflict with 2.1.
5. `AGENT.md` and all other operator language are design artifacts, not executable controls.

## Verify

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src python3 scripts/verify_bundle.py
```

To create a fresh isolated pilot database:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
  python3 scripts/bootstrap.py --db /absolute/path/to/pilot.db
```

To reproduce the legacy audit against the supplied V2 evidence pack:

```bash
python3 audit_referential_integrity.py /absolute/path/to/v2-pack
```

Expected finding-set hash:
`bd8d706fa67b7b38f3c5e249dbe0a3496e220466ded85f08fd8cc91f4cefeba9`.

## Implemented in 2.1

- Versioned source and route universe with both route and expected-volume coverage.
- Legal/purpose/retention policy state required before route fetches.
- Immutable source/route policy reviews pinned to frozen universes and fetch attempts.
- Atomic job queue with mission foreign keys, idempotency keys and expiring worker leases.
- Immutable, atomic, content-addressed artifact store.
- Multiple artifact roles per fetch attempt, including DOM and screenshot.
- Replay-safe 304 handling through an explicit reused-body artifact.
- Route-run and parse-run boundaries with exact fetch/input links and artifact-set hashes.
- Source records and append-only field observations with per-field evidence.
- Pure versioned terminal-state calculator; no mutable `route.route_state`.
- Fetch-derived freshness with automatic stale demotion from coverage after two refetch windows.
- Evidence-derived audit, fixture, field-health, empty-result and corroboration gates.
- Append-only manual corrections with separate approval and supersession history.
- Replay-gated exact-match feedback rules, scoped route → template → global.
- Source-scoped provider identifiers and materialization lineage.
- Enforced adapter fixtures and honest fallback declarations.
- Deterministic fetch rate-limit/circuit-breaker policy.
- Strict legacy audit whose exit status includes dangling references and counter errors.
- Automated unit/integration tests and a self-verifying manifest.

## Deliberately not claimed complete

No production fetch transport, adapter interpreter, five real adapters, entity resolver,
materializer, egress-proxy deployment, legacy recovery ledger, or production merge has been
completed. The five pilot routes remain candidates with policy/legal review pending. See
`FOUNDATION-2.1.md` for the exact gates.
