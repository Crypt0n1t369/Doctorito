#!/usr/bin/env python3
"""Verify manifest, schema, seeds, bootstrap and executable controls."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verify_manifest() -> None:
    manifest = json.loads((ROOT / "HANDOFF-MANIFEST.json").read_text(encoding="utf-8"))
    mismatches = []
    actual = {
        str(path.relative_to(ROOT)) for path in ROOT.rglob("*")
        if path.is_file() and not path.is_symlink() and path.name not in
           ("HANDOFF-MANIFEST.json", ".DS_Store")
        and "__pycache__" not in path.relative_to(ROOT).parts and path.suffix != ".pyc"
    }
    expected_names = set(manifest["files"])
    for name in sorted(actual - expected_names):
        mismatches.append(f"untracked {name}")
    for name in sorted(expected_names - actual):
        mismatches.append(f"missing {name}")
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file():
            mismatches.append(f"missing {name}")
            continue
        data = path.read_bytes()
        if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            mismatches.append(f"changed {name}")
    if mismatches:
        raise RuntimeError("manifest mismatch: " + ", ".join(mismatches))


def verify_schema_and_bootstrap() -> None:
    with tempfile.TemporaryDirectory() as directory:
        db = Path(directory) / "pilot.db"
        subprocess.run(
            [sys.executable, str(ROOT / "scripts/bootstrap.py"), "--db", str(db)],
            cwd=ROOT, check=True, env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
            stdout=subprocess.DEVNULL,
        )
        con = sqlite3.connect(db)
        try:
            violations = con.execute("PRAGMA foreign_key_check").fetchall()
            version = con.execute("SELECT schema_version FROM schema_meta").fetchone()[0]
            counts = tuple(con.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
                           for table in ("mission", "source", "route"))
        finally:
            con.close()
        if violations or version != "2.1.0" or counts != (5, 5, 5):
            raise RuntimeError(
                f"bootstrap verification failed: version={version}, counts={counts}, violations={violations}"
            )


def verify_tests() -> None:
    subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-v"], cwd=ROOT, check=True,
        env={**os.environ, "PYTHONPATH": str(ROOT / "src"), "PYTHONDONTWRITEBYTECODE": "1"},
    )


def main() -> int:
    verify_manifest()
    verify_schema_and_bootstrap()
    verify_tests()
    print("bundle verified: manifest, schema 2.1.0, seeds, bootstrap and tests")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
