#!/usr/bin/env python3
"""Create an isolated v2.1 database and load governed seed data."""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tcpipe.db import assert_db_integrity, open_db  # noqa: E402


def load_and_validate(document_name: str, schema_name: str) -> dict:
    document = json.loads((ROOT / document_name).read_text(encoding="utf-8"))
    schema = json.loads((ROOT / schema_name).read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(document)
    return document


def create_database(path: Path) -> None:
    if path.exists():
        raise SystemExit(f"refusing to overwrite existing database: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    try:
        con.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
    finally:
        con.close()


def seed_database(path: Path) -> None:
    missions = load_and_validate("missions.json", "missions.schema.json")
    universe = load_and_validate("source-universe.seed.json", "source-universe.schema.json")
    source_ids = [source["source_id"] for source in universe["sources"]]
    route_ids = [route["route_id"] for route in universe["routes"]]
    if len(source_ids) != len(set(source_ids)) or len(route_ids) != len(set(route_ids)):
        raise SystemExit("duplicate source_id or route_id in universe seed")
    unknown = sorted({route["source_id"] for route in universe["routes"]} - set(source_ids))
    if unknown:
        raise SystemExit(f"routes reference unknown sources: {unknown}")

    con = open_db(path, required_schema_version="2.1.0")
    con.execute("BEGIN IMMEDIATE")
    try:
        for mission in missions["missions"]:
            con.execute(
                "INSERT INTO mission VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    mission["mission_id"], mission["track"], mission["title"],
                    mission["problem"], mission["done_when"], mission["priority"],
                    int(mission["blocks_production"]), 1, "2026-08-19T00:00:00Z",
                ),
            )
        u = universe["universe"]
        con.execute(
            "INSERT INTO source_universe VALUES (?,?,?,?,?,?)",
            (u["universe_id"], u["version"], u["scope_statement"], u["status"],
             u["created_at_utc"], u.get("frozen_at_utc")),
        )
        for source in universe["sources"]:
            con.execute(
                """INSERT INTO source
                   (source_id,legal_name,acronym,source_kind,country_iso2,official_website,
                    discovered_via,intake_state,terms_url,license_basis,allowed_purpose,
                    retention_period,legal_review_state,last_legal_review_utc,created_at_utc)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                tuple(source.get(name) for name in (
                    "source_id", "legal_name", "acronym", "source_kind", "country_iso2",
                    "official_website", "discovered_via", "intake_state", "terms_url",
                    "license_basis", "allowed_purpose", "retention_period",
                    "legal_review_state", "last_legal_review_utc", "created_at_utc",
                )),
            )
            con.execute(
                """INSERT INTO universe_source
                   (universe_id,source_id,eligibility,exclusion_reason) VALUES (?,?,?,?)""",
                (u["universe_id"], source["source_id"], source["eligibility"],
                 source.get("exclusion_reason")),
            )
        for route in universe["routes"]:
            con.execute(
                """INSERT INTO route
                   (route_id,source_id,route_url,scheme_scope,route_kind,acquisition_method,
                    policy_state,robots_state,robots_snapshot_sha,crawl_delay_s,volatility_class,
                    refetch_days,created_at_utc) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                tuple(route.get(name) for name in (
                    "route_id", "source_id", "route_url", "scheme_scope", "route_kind",
                    "acquisition_method", "policy_state", "robots_state", "robots_snapshot_sha",
                    "crawl_delay_s", "volatility_class", "refetch_days", "created_at_utc",
                )),
            )
            con.execute(
                """INSERT INTO universe_route
                   (universe_id,route_id,eligibility,exclusion_reason,expected_records,
                    expected_basis,expected_as_of_utc) VALUES (?,?,?,?,?,?,?)""",
                (u["universe_id"], route["route_id"], route["eligibility"],
                 route.get("exclusion_reason"), route.get("expected_records"),
                 route.get("expected_basis"), route.get("expected_as_of_utc")),
            )
        con.execute("COMMIT")
        assert_db_integrity(con)
    except Exception:
        con.execute("ROLLBACK")
        raise
    finally:
        con.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, required=True)
    args = parser.parse_args()
    create_database(args.db)
    seed_database(args.db)
    print(f"created {args.db} with schema 2.1.0 and validated seeds")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
