"""Operator command line for instructing and overseeing the parsing instrument."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any, Optional, Sequence

from .db import open_db
from .writer import enqueue_job, utc_now

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_VERSION = "2.1.0"


def _id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:20].upper()}"


def _json_print(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, default=str))


def _load_json(value: str) -> dict[str, Any]:
    if value.startswith("@"):
        value = Path(value[1:]).read_text(encoding="utf-8")
    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise ValueError("job parameters must be a JSON object")
    return parsed


def _connect(path: str, *, readonly: bool = False) -> sqlite3.Connection:
    return open_db(path, readonly=readonly, required_schema_version=SCHEMA_VERSION)


def command_init(args: argparse.Namespace) -> int:
    db = Path(args.db).expanduser().resolve()
    artifacts = Path(args.artifacts).expanduser().resolve()
    subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "bootstrap.py"), "--db", str(db)],
        cwd=ROOT,
        check=True,
        env={**os.environ, "PYTHONPATH": str(ROOT / "src"), "PYTHONDONTWRITEBYTECODE": "1"},
        stdout=subprocess.DEVNULL,
    )
    artifacts.mkdir(parents=True, exist_ok=True)
    _json_print({
        "database": str(db),
        "artifact_store": str(artifacts),
        "next": [
            f"./tcpipe status --db {db}",
            "Review OPERATOR-GUIDE.md before approving sources or fetching.",
        ],
    })
    return 0


def command_status(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        scalar_groups = {}
        for name, sql in {
            "jobs": "SELECT status,count(*) n FROM job_queue GROUP BY status",
            "current_routes": (
                "SELECT COALESCE(terminal_state,'never_run') status,count(*) n "
                "FROM v_route_current_status GROUP BY COALESCE(terminal_state,'never_run')"
            ),
            "escalations": "SELECT status,count(*) n FROM escalation GROUP BY status",
            "reviews": "SELECT status,count(*) n FROM review_queue GROUP BY status",
        }.items():
            scalar_groups[name] = {row["status"]: row["n"] for row in con.execute(sql)}
        correction_rows = con.execute(
            """SELECT COALESCE(md.decision,'pending') status,count(*) n
                 FROM manual_correction mc LEFT JOIN manual_correction_decision md
                   ON md.correction_id=mc.correction_id
                GROUP BY COALESCE(md.decision,'pending')"""
        ).fetchall()
        coverage = [dict(row) for row in con.execute(
            "SELECT * FROM v_universe_coverage ORDER BY universe_id"
        )]
        missions = [dict(row) for row in con.execute(
            """SELECT mission_id,track,title,blocks_production FROM mission
               WHERE active=1 ORDER BY track,priority"""
        )]
        _json_print({
            "schema_version": SCHEMA_VERSION,
            "missions": missions,
            **scalar_groups,
            "manual_corrections": {row["status"]: row["n"] for row in correction_rows},
            "active_correction_rules": con.execute(
                """SELECT count(*) FROM correction_rule cr WHERE NOT EXISTS (
                   SELECT 1 FROM correction_rule child
                    WHERE child.supersedes_rule_id=cr.correction_rule_id)"""
            ).fetchone()[0],
            "coverage": coverage,
            "attention": {
                "expired_running_leases": con.execute(
                    """SELECT count(*) FROM job_queue WHERE status='running'
                       AND julianday(lease_expires_at_utc)<=julianday('now')"""
                ).fetchone()[0],
                "open_blocking_escalations": con.execute(
                    "SELECT count(*) FROM escalation WHERE status IN ('open','in_progress')"
                ).fetchone()[0],
                "pending_manual_corrections": con.execute(
                    """SELECT count(*) FROM manual_correction mc WHERE NOT EXISTS
                       (SELECT 1 FROM manual_correction_decision md
                         WHERE md.correction_id=mc.correction_id)"""
                ).fetchone()[0],
                "pending_rule_reviews": con.execute(
                    """SELECT count(*) FROM review_queue
                       WHERE status='pending' AND review_kind='correction_rule_candidate'"""
                ).fetchone()[0],
            },
        })
        return 0
    finally:
        con.close()


def command_missions(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        _json_print([dict(row) for row in con.execute(
            "SELECT * FROM mission ORDER BY track,priority"
        )])
        return 0
    finally:
        con.close()


def command_enqueue(args: argparse.Namespace) -> int:
    con = _connect(args.db)
    try:
        job_id = args.job_id or _id("JOB")
        params = _load_json(args.params) if args.params else {
            "objective": args.instruction,
            "route_ids": args.route or [],
            "acceptance": args.acceptance or [],
            "execution_mode": args.mode,
        }
        created = enqueue_job(
            con,
            job_id=job_id,
            mission_id=args.mission,
            kind=args.kind,
            params=params,
            git_commit=args.git_commit,
            idempotency_key=args.idempotency_key,
            priority=args.priority,
            max_attempts=args.max_attempts,
            actor=args.by,
        )
        if not created:
            job_id = con.execute(
                "SELECT job_id FROM job_queue WHERE idempotency_key=?",
                (args.idempotency_key,),
            ).fetchone()[0]
        _json_print({"job_id": job_id, "created": created})
        return 0
    finally:
        con.close()


def command_jobs(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        params: tuple[Any, ...] = ()
        where = ""
        if args.status:
            where, params = "WHERE status=?", (args.status,)
        rows = con.execute(
            f"""SELECT job_id,mission_id,kind,status,priority,attempt_count,max_attempts,
                       claimed_by,lease_expires_at_utc,created_at_utc,finished_at_utc,
                       outcome_detail_json
                  FROM job_queue {where}
                 ORDER BY created_at_utc DESC,job_id LIMIT ?""",
            (*params, args.limit),
        )
        _json_print([dict(row) for row in rows])
        return 0
    finally:
        con.close()


def command_routes(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        rows = con.execute(
            """SELECT r.route_id,r.source_id,s.legal_name,r.route_url,r.route_kind,
                      r.acquisition_method,r.volatility_class,r.refetch_days,
                      GROUP_CONCAT(ur.universe_id || ':' || ur.eligibility) universes,
                      vcs.run_id,vcs.terminal_state,vcs.terminal_reason,vcs.finished_at_utc,
                      vcs.extracted_count
                 FROM route r JOIN source s ON s.source_id=r.source_id
                 LEFT JOIN universe_route ur ON ur.route_id=r.route_id
                 LEFT JOIN v_route_current_status vcs ON vcs.route_id=r.route_id
                GROUP BY r.route_id ORDER BY r.route_id LIMIT ?""",
            (args.limit,),
        )
        _json_print([dict(row) for row in rows])
        return 0
    finally:
        con.close()


def command_observations(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        clauses: list[str] = []
        values: list[Any] = []
        if args.route:
            clauses.append("rr.route_id=?")
            values.append(args.route)
        if args.field:
            clauses.append("efo.field_name=?")
            values.append(args.field)
        if args.contains:
            clauses.append(
                "(efo.raw_value LIKE ? OR COALESCE(efo.effective_normalized_value,'') LIKE ?)"
            )
            values.extend((f"%{args.contains}%", f"%{args.contains}%"))
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        rows = con.execute(
            f"""SELECT efo.field_observation_id,rr.route_id,pr.parse_run_id,
                       sr.source_record_key,efo.field_name,efo.raw_value,
                       efo.parser_normalized_value,efo.effective_normalized_value,
                       efo.effective_value_source,efo.correction_id,efo.field_locator,
                       efo.evidence_quote,efo.artifact_sha256
                  FROM v_effective_field_observation efo
                  JOIN source_record sr ON sr.source_record_id=efo.source_record_id
                  JOIN parse_run pr ON pr.parse_run_id=sr.parse_run_id
                  JOIN route_run rr ON rr.run_id=pr.route_run_id
                  {where}
                 ORDER BY rr.route_id,sr.row_ordinal,efo.field_name,efo.value_ordinal LIMIT ?""",
            (*values, args.limit),
        )
        _json_print([dict(row) for row in rows])
        return 0
    finally:
        con.close()


def command_correction_propose(args: argparse.Namespace) -> int:
    con = _connect(args.db)
    correction_id = args.correction_id or _id("COR")
    try:
        con.execute("BEGIN IMMEDIATE")
        con.execute(
            """INSERT INTO manual_correction
               (correction_id,field_observation_id,action,corrected_normalized_value,
                scope,reason,proposed_by,proposed_at_utc,supersedes_correction_id)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                correction_id,
                args.observation,
                args.action,
                args.value,
                args.scope,
                args.reason,
                args.by,
                utc_now(),
                args.supersedes,
            ),
        )
        con.execute("COMMIT")
        _json_print({
            "correction_id": correction_id,
            "status": "pending",
            "next": f"./tcpipe correction-decide --db {args.db} --correction {correction_id} "
                    "--decision accepted --by REVIEWER --rationale 'verified against source'",
        })
        return 0
    except Exception:
        con.execute("ROLLBACK")
        raise
    finally:
        con.close()


def _correction_context(con: sqlite3.Connection, correction_id: str) -> sqlite3.Row:
    row = con.execute(
        """SELECT mc.*,fo.field_name,fo.raw_value,fo.normalized_value,sr.source_record_key,
                  rr.route_id,rr.adapter_id,rr.adapter_version,r.route_url,a.template_fingerprint
             FROM manual_correction mc
             JOIN field_observation fo ON fo.field_observation_id=mc.field_observation_id
             JOIN source_record sr ON sr.source_record_id=fo.source_record_id
             JOIN parse_run pr ON pr.parse_run_id=sr.parse_run_id
             JOIN route_run rr ON rr.run_id=pr.route_run_id
             JOIN route r ON r.route_id=rr.route_id
             LEFT JOIN adapter a ON a.adapter_id=rr.adapter_id AND a.version=rr.adapter_version
            WHERE mc.correction_id=?""",
        (correction_id,),
    ).fetchone()
    if row is None:
        raise ValueError(f"correction not found: {correction_id}")
    return row


def command_correction_decide(args: argparse.Namespace) -> int:
    con = _connect(args.db)
    try:
        con.execute("BEGIN IMMEDIATE")
        correction = _correction_context(con, args.correction)
        review_id: Optional[str] = None
        if args.decision == "accepted" and correction["scope"] != "one_record":
            review_id = args.review_id or _id("REV")
            payload = {
                "correction_id": correction["correction_id"],
                "route_id": correction["route_id"],
                "route_url": correction["route_url"],
                "adapter_id": correction["adapter_id"],
                "adapter_version": correction["adapter_version"],
                "template_fingerprint": correction["template_fingerprint"],
                "field_name": correction["field_name"],
                "action": correction["action"],
                "corrected_normalized_value": correction["corrected_normalized_value"],
                "reason": correction["reason"],
                "required_before_promotion": [
                    "encode scoped adapter/rule change",
                    "add or update golden fixture",
                    "replay unchanged artifact set",
                    "compare canonical projection and row count",
                ],
            }
            con.execute(
                """INSERT INTO review_queue
                   (review_id,review_kind,payload_json,proposed_by,status)
                   VALUES (?,?,?,?,?)""",
                (review_id, "correction_rule_candidate", json.dumps(payload, sort_keys=True),
                 "operator_feedback", "pending"),
            )
        con.execute(
            """INSERT INTO manual_correction_decision
               (correction_id,decision,decided_by,rationale,rule_candidate_review_id,decided_at_utc)
               VALUES (?,?,?,?,?,?)""",
            (args.correction, args.decision, args.by, args.rationale, review_id, utc_now()),
        )
        con.execute("COMMIT")
        _json_print({
            "correction_id": args.correction,
            "decision": args.decision,
            "effective_immediately": args.decision == "accepted",
            "rule_candidate_review_id": review_id,
            "safety": (
                "The source observation remains unchanged. Broader reuse is pending fixture replay."
                if review_id else "The correction is scoped to one record."
            ),
        })
        return 0
    except Exception:
        con.execute("ROLLBACK")
        raise
    finally:
        con.close()


def command_corrections(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        rows = con.execute(
            """SELECT mc.*,md.decision,md.decided_by,md.rationale,
                      md.rule_candidate_review_id,md.decided_at_utc,
                      CASE WHEN md.decision='accepted' AND NOT EXISTS (
                        SELECT 1 FROM manual_correction child
                        JOIN manual_correction_decision child_decision
                          ON child_decision.correction_id=child.correction_id
                         WHERE child.supersedes_correction_id=mc.correction_id
                           AND child_decision.decision='accepted') THEN 1 ELSE 0 END effective
                 FROM manual_correction mc LEFT JOIN manual_correction_decision md
                   ON md.correction_id=mc.correction_id
                ORDER BY mc.proposed_at_utc DESC,mc.correction_id LIMIT ?""",
            (args.limit,),
        )
        _json_print([dict(row) for row in rows])
        return 0
    finally:
        con.close()


def command_reviews(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        rows = con.execute(
            """SELECT review_id,review_kind,payload_json,proposed_by,confidence,status,
                      decided_by,decision_rationale,decided_at_utc
                 FROM review_queue WHERE (? IS NULL OR status=?)
                ORDER BY status,review_id LIMIT ?""",
            (args.status, args.status, args.limit),
        )
        _json_print([dict(row) for row in rows])
        return 0
    finally:
        con.close()


def _rule_review_context(con: sqlite3.Connection, review_id: str) -> tuple[sqlite3.Row, sqlite3.Row]:
    review = con.execute(
        """SELECT rq.*,md.correction_id FROM review_queue rq
           JOIN manual_correction_decision md ON md.rule_candidate_review_id=rq.review_id
          WHERE rq.review_id=? AND rq.review_kind='correction_rule_candidate'""",
        (review_id,),
    ).fetchone()
    if review is None:
        raise ValueError(f"correction rule review not found: {review_id}")
    if review["status"] != "pending":
        raise ValueError(f"review {review_id} is already {review['status']}")
    return review, _correction_context(con, review["correction_id"])


def command_review_decide(args: argparse.Namespace) -> int:
    con = _connect(args.db)
    try:
        con.execute("BEGIN IMMEDIATE")
        review, correction = _rule_review_context(con, args.review)
        now = utc_now()
        con.execute(
            """UPDATE review_queue SET status=?,decided_by=?,decision_rationale=?,decided_at_utc=?
               WHERE review_id=? AND status='pending'""",
            (args.decision, args.by, args.rationale, now, args.review),
        )
        rule_id: Optional[str] = None
        if args.decision == "accepted":
            required = {
                "projection_hash_before": args.before_hash,
                "projection_hash_after": args.after_hash,
                "fixture_count": args.fixture_count,
                "affected_observation_count": args.affected,
                "row_count_delta": args.row_delta,
            }
            missing = [name for name, value in required.items() if value is None]
            if missing:
                raise ValueError(
                    "accepting a learned rule requires replay evidence: " + ", ".join(missing)
                )
            if correction["scope"] == "global_candidate":
                scope_kind, scope_value = "global", ""
            elif correction["template_fingerprint"]:
                scope_kind, scope_value = (
                    "template_fingerprint", correction["template_fingerprint"]
                )
            else:
                scope_kind, scope_value = "route_id", correction["route_id"]
            rule_id = args.rule_id or _id("CRULE")
            con.execute(
                """INSERT INTO correction_rule
                   (correction_rule_id,review_id,origin_correction_id,field_name,
                    match_raw_value,action,replacement_normalized_value,scope_kind,scope_value,
                    fixture_count,projection_hash_before,projection_hash_after,
                    affected_observation_count,row_count_delta,row_drop_justification,
                    replayed_by,replayed_at_utc,supersedes_rule_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    rule_id, review["review_id"], correction["correction_id"],
                    correction["field_name"], correction["raw_value"], correction["action"],
                    correction["corrected_normalized_value"], scope_kind, scope_value,
                    args.fixture_count, args.before_hash, args.after_hash, args.affected,
                    args.row_delta, args.row_drop_justification, args.by, now, args.supersedes_rule,
                ),
            )
        con.execute("COMMIT")
        _json_print({
            "review_id": args.review,
            "decision": args.decision,
            "correction_rule_id": rule_id,
            "effect": (
                "Future exact raw-value matches in this scope now receive the governed rule."
                if rule_id else "No reusable rule was created."
            ),
        })
        return 0
    except Exception:
        con.execute("ROLLBACK")
        raise
    finally:
        con.close()


def _verify_artifact(path: Path, expected_hash: str, expected_length: int) -> Optional[str]:
    if not path.is_file():
        return "missing"
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
            size += len(chunk)
    if size != expected_length:
        return f"length mismatch: expected {expected_length}, got {size}"
    actual = digest.hexdigest()
    return None if actual == expected_hash else f"hash mismatch: got {actual}"


def command_doctor(args: argparse.Namespace) -> int:
    con = _connect(args.db, readonly=True)
    try:
        fk = [tuple(row) for row in con.execute("PRAGMA foreign_key_check")]
        quick = con.execute("PRAGMA quick_check").fetchone()[0]
        artifact_issues = []
        sql = "SELECT sha256,byte_len,storage_path FROM artifact ORDER BY first_seen_at_utc"
        if args.artifact_limit > 0:
            sql += f" LIMIT {int(args.artifact_limit)}"
        artifacts = con.execute(sql).fetchall()
        for row in artifacts:
            issue = _verify_artifact(Path(row["storage_path"]), row["sha256"], row["byte_len"])
            if issue:
                artifact_issues.append({"sha256": row["sha256"], "issue": issue})
        result = {
            "ok": quick == "ok" and not fk and not artifact_issues,
            "sqlite_quick_check": quick,
            "foreign_key_violations": fk,
            "artifacts_checked": len(artifacts),
            "artifact_issues": artifact_issues,
        }
        _json_print(result)
        return 0 if result["ok"] else 1
    finally:
        con.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tcpipe",
        description="Instruct, oversee and correct the training-centre parsing instrument.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="Create an isolated database and artifact directory")
    init.add_argument("--db", required=True)
    init.add_argument("--artifacts", required=True)
    init.set_defaults(func=command_init)

    for name, function, help_text in (
        ("status", command_status, "Show missions, work, coverage and attention items"),
        ("missions", command_missions, "List the instruction/mission registry"),
        ("jobs", command_jobs, "List queued and completed instructions"),
        ("routes", command_routes, "List source routes and current outcomes"),
        ("observations", command_observations, "Find evidence-backed fields to inspect or correct"),
        ("corrections", command_corrections, "List manual corrections and decisions"),
        ("reviews", command_reviews, "List human-review and learned-rule candidates"),
        ("doctor", command_doctor, "Check database and stored-artifact integrity"),
    ):
        command = sub.add_parser(name, help=help_text)
        command.add_argument("--db", required=True)
        if name in ("jobs", "reviews"):
            command.add_argument("--status")
        if name in ("jobs", "corrections", "reviews", "routes", "observations"):
            command.add_argument("--limit", type=int, default=100)
        if name == "observations":
            command.add_argument("--route")
            command.add_argument("--field")
            command.add_argument("--contains")
        if name == "doctor":
            command.add_argument(
                "--artifact-limit", type=int, default=0,
                help="0 checks all registered artifacts",
            )
        command.set_defaults(func=function)

    enqueue = sub.add_parser("enqueue", help="Give the instrument a governed work instruction")
    enqueue.add_argument("--db", required=True)
    enqueue.add_argument("--mission", required=True)
    enqueue.add_argument("--kind", required=True)
    instruction_input = enqueue.add_mutually_exclusive_group(required=True)
    instruction_input.add_argument("--params", help="JSON object or @path/to/file.json")
    instruction_input.add_argument("--instruction", help="Plain-language governed objective")
    enqueue.add_argument("--route", action="append", help="Route ID; repeat when needed")
    enqueue.add_argument(
        "--acceptance", action="append", help="Acceptance condition; repeat when needed"
    )
    enqueue.add_argument(
        "--mode", choices=("observe_only", "isolated_pilot", "governed_write"),
        default="isolated_pilot",
    )
    enqueue.add_argument("--idempotency-key", required=True)
    enqueue.add_argument("--git-commit", required=True)
    enqueue.add_argument("--by", required=True)
    enqueue.add_argument("--job-id")
    enqueue.add_argument("--priority", type=int, default=100)
    enqueue.add_argument("--max-attempts", type=int, default=3)
    enqueue.set_defaults(func=command_enqueue)

    propose = sub.add_parser(
        "correction-propose", help="Propose an append-only correction to one observation"
    )
    propose.add_argument("--db", required=True)
    propose.add_argument("--observation", required=True)
    propose.add_argument(
        "--action", required=True,
        choices=("replace_normalized", "reject_value", "reject_record"),
    )
    propose.add_argument("--value", help="Required only for replace_normalized")
    propose.add_argument(
        "--scope", required=True,
        choices=("one_record", "route_template", "global_candidate"),
    )
    propose.add_argument("--reason", required=True)
    propose.add_argument("--by", required=True)
    propose.add_argument("--supersedes")
    propose.add_argument("--correction-id")
    propose.set_defaults(func=command_correction_propose)

    decide = sub.add_parser(
        "correction-decide", help="Accept or reject a proposed correction"
    )
    decide.add_argument("--db", required=True)
    decide.add_argument("--correction", required=True)
    decide.add_argument("--decision", required=True, choices=("accepted", "rejected"))
    decide.add_argument("--by", required=True)
    decide.add_argument("--rationale", required=True)
    decide.add_argument("--review-id")
    decide.set_defaults(func=command_correction_decide)

    review_decide = sub.add_parser(
        "review-decide", help="Accept/reject a learned correction rule after fixture replay"
    )
    review_decide.add_argument("--db", required=True)
    review_decide.add_argument("--review", required=True)
    review_decide.add_argument("--decision", required=True, choices=("accepted", "rejected"))
    review_decide.add_argument("--by", required=True)
    review_decide.add_argument("--rationale", required=True)
    review_decide.add_argument("--before-hash")
    review_decide.add_argument("--after-hash")
    review_decide.add_argument("--fixture-count", type=int)
    review_decide.add_argument("--affected", type=int)
    review_decide.add_argument("--row-delta", type=int)
    review_decide.add_argument("--row-drop-justification")
    review_decide.add_argument("--rule-id")
    review_decide.add_argument("--supersedes-rule")
    review_decide.set_defaults(func=command_review_decide)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except (ValueError, sqlite3.Error, subprocess.CalledProcessError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
