"""Deterministic core for the training-centre parsing instrument."""

__version__ = "2.1.0"

